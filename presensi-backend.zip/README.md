Backend Aplikasi Presensi

Postman api :
https://drive.google.com/file/d/1lOIBfz-xo-2ksL6a2_PqI9oodsyasUs2/view?usp=sharing

Video Cara Install :
https://youtu.be/Q4SuIqcGJoY
