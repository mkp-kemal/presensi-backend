

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Rekap Presensi</div>
                
                <div class="card-body">
                <table id="example" class="table table-striped" style="width:100%">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Waktu</th>
                            <th>Masuk</th>
                            <th>Pulang</th>
                            <th>Lokasi (Latitude, Longitude)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $presensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->tanggal); ?></td>
                            <td><?php echo e($item->masuk); ?></td>
                            <td><?php echo e($item->pulang); ?></td>
                            <td><?php echo e($item->latitude); ?>, <?php echo e($item->longitude); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
       
        
    </div>
</div>
<script type="text/javascript" class="init">
	

$(document).ready(function () {
	var table = $('#example').DataTable( {
        rowReorder: {
            selector: 'td:nth-child(2)'
        },
        responsive: true
    } );
});

</script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\_MataKuliah\Semester 5\Pengembangan Aplikasi Mobile\UAS PROJECT\presensi-backend\resources\views/home.blade.php ENDPATH**/ ?>